<div class="general__holder">
  <header class="heading__wrapper">
    <h1>Ops!! Something went wrong.</h1>
    <h1>Please try again.</h1>
    <p>If problem persists, contact the web administrator.</p>
    <p>Thank you.</p>
  </header>
</div>