<?php

class Unit extends CI_Controller {
  public function __construct() {
    parent::__construct();
    $this->load->helper('url_helper');
  }

  function index() {
    $this->load->model('units_model');

    $data['units'] = $this->db->get_where('units')->result();

    $this->load->view('templates/header');
    $this->load->view('unit/unit', $data);
    $this->load->view('templates/footer');
  }

  function unitAdd() {
    $this->load->view('templates/header');
    $this->load->view('unit/add');
    $this->load->view('templates/footer');
  }

  function add() {
    $this->load->model('units_model');

    $unit_code = $this->input->get_post('unit_code');
    $unit_name = $this->input->get_post('unit_name');
    $unit_activities = $this->input->get_post('activity');
    if(isset($unit_activities)) {
      $activities = array();

      foreach ($unit_activities as $activity) {
        array_push($activities, $activity);
      }
      $activities = implode(",", $activities);
    }

    $check = $this->units_model->findUnitWithUnitCode($unit_code);
    if(!$check) {
      $data = array(
        'unit_code' => $unit_code,
        'unit_name' => $unit_name,
        'activities' => $activities,
        'activities_modified' => date('Y-m-d H:i:s')
      );
      $this->db->insert('units', $data);
    } else {
      echo 'Unit already exists.';
    }
  }
}


