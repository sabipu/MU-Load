<?php

class Metrics extends CI_Controller {
  public function __construct() {
    parent::__construct();
  }

  function index() {
    $this->load->view('templates/header');
    $this->load->view('metrics/metrics');
    $this->load->view('templates/footer');
  }

  function addMetrics() {
    $this->load->view('templates/header');
    $this->load->view('metrics/add');
    $this->load->view('templates/footer');
  }

  function add() {
    $this->load->model('metrics_model');

    $metrics_title = $this->input->get_post('metrics_title');
    $metrics_notes = $this->input->get_post('metrics_notes');
    $formula_value = $this->input->get_post('formula_value');
    $metrics_code = $this->input->get_post('metrics_code');

    $data = array(
      'metrics_code' => $metrics_code,
      'metrics_title' => $metrics_title,
      'formula_or_value' => 1,
      'metrics_variable' => 2,
      'metrics_note' => 3,
      'formula_or_value_output' => $unit_name,
      'associated_activity' => $unit_name,
    );
  }
}