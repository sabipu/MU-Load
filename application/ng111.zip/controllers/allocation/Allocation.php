<?php

class Allocation extends CI_Controller {
  public function __construct() {
    parent::__construct();
  }

  function index() {
    $this->load->model('users_model');
    $this->load->model('units_model');
    $this->load->view('templates/header');

    $data['users'] = $this->db->get_where('users', array('status' => 'active'))->result();
    $data['units'] = $this->db->get_where('units')->result();

    $this->load->view('allocation/allocation', $data);
    $this->load->view('templates/footer');
  }

  function add() {
    $this->load->model('users_model');
    $this->load->model('units_model');

    $user_id = $this->input->get_post('user');
    $unit_id = $this->input->get_post('unit');

    $check = $this->units_model->checkIfUnitIsAssigned($unit_id);

    if(!$check) {
      $updatedData = array(
        'assigned_to' => $user_id,
        'assigned_on' => date('Y-m-d H:i:s'),
        'assigned_date_modified' => date('Y-m-d H:i:s'),
        'status' => 'assigned',
      );

      $this->db->where('unit_id', $unit_id);
      $this->db->update('units', $updatedData);

      echo 'Allocation added';

    } else {
      echo 'Allocation exists';
    }
  }

  function allocate() {
    $this->load->view('templates/header');
    $this->load->view('allocation/allocate');
    $this->load->view('templates/footer');
  }
}


