<?php 
function random_color_part() {
  return str_pad( dechex( mt_rand( 0, 255 ) ), 2, '0', STR_PAD_LEFT);
}

function random_color() {
  return random_color_part() . random_color_part() . random_color_part();
}
?>
<div class="general__holder">
  <header class="heading__wrapper">
    <a href="/metrics-add" class="button">Add new metrics</a>
    <h1>Allocation Metrics</h1>
    <p>Manage units and activities associated with units.</p>
  </header>
  <table class="data__table">
    <thead>
      <tr>
        <th>Code</th>
        <th>Title</th>
        <th>Formula</th>
        <th>Variables</th>
        <th>Notes</th>
        <th>Activity</th>
        <th>Total Hours</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
        <tr>
          <td>
            <div class="formula__code">u21 & u28</div>
          </td>
          <td>
            <span class="formula__title">Unit Coordination</span>
            <span class="formula__sub">Transnational</span>
          </td>
          <td>
            <div class="formula">
              30 + (k - 1) * 10)
            </div>
          </td>
          <td>
            <label class="variable__val">
              <span class="variable-title">Value of n</span>
              <input type="text" value="">
            </label>
          </td>
          <td>
            <div class="metrics__desc">where k = number of same unit offerings in the same teaching period</div>
          </td>
          <td>
            <div class="total_hour">
              20hr
            </div>
          </td>
          <td>
            <div class="activity">
              Coordination
            </div>
          </td>
          <td>
            <a href="#" class="button button-nobg button-small">Edit</a>
            <a href="#" class="button button-small">Delete</a>
          </td>
        </tr>
    </tbody>
  </table>
</div>
