<?php 
function random_color_part() {
  return str_pad( dechex( mt_rand( 0, 255 ) ), 2, '0', STR_PAD_LEFT);
}

function random_color() {
  return random_color_part() . random_color_part() . random_color_part();
}
?>
<div class="general__holder">
  <header class="heading__wrapper">
    <a href="/register" class="button">Add new staff</a>
    <h1>Manage Staff</h1>
    <p>Manage staff member and change hour allocations.</p>
  </header>
  <table class="data__table">
    <thead>
      <tr>
        <th>&nbsp;</th>
        <th>Name</th>
        <th>Email address</th>
        <th>Role</th>
        <th>Status</th>
        <th>Teaching Hour</th>
        <th>Modified</th>
        <th>&nbsp;</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($users as $user) : ?>
      <tr data-userid="<?= $user->user_id ?>">
        <td>
          <div class="user_profile" style="background-color: #<?= random_color(); ?>"><?= $user->first_name[0] ?><?= $user->last_name[0] ?></div>
        </td>
        <td>
          <div class="user_name"><?= $user->name ?></div>
        </td>
        <td>
          <div class="user_email"><?= $user->email ?></div>
        </td>
        <td>
          <div class="user_role"><?= $user->role ?></div>
        </td>
        <td>
          <?php 
            if($user->status === 'active') {
              $stat = 'checked';
            } else {
              $stat = '';
            }
          ?>
          <div class="user_status">
            <label class="custom-status">
              <input type="checkbox" <?= $stat ?>>
              <span class="custom-statusbox"></span>
              <span class="custom-statustext"><span class="active">Active</span><span class="deactive">Deactive</span></span>
            </label>
          </div>
        </td>
        <td>
          1400
        </td>
        <td>
          date
          <?= $user->modified ?>
        </td>
        <td>
          <a href="#" class="button button-small button-nobg">Edit user</a>
          <a href="#" class="button button-small">Delete User</a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
