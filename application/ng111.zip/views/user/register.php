<div class="general__holder">
  <header class="heading__wrapper">
    <a href="/manage-staff" class="button">Manage Staff</a>
    <h1>Register a staff member.</h1>
    <p>Please use the form below to register academic staff member or casual staff member.</p>
  </header>
  <form method="post" class="register__form general__form" action="<?php echo site_url('register/add') ?>">
    <div class="form_group">
      <!-- <input class="form_control" type="text" name="username" placeholder="Username"> -->
    </div>
    <div class="row">
      <div class="col-sm-6">
        <div class="form_group">
          <input class="form_control" type="text" name="fname" placeholder="First Name">
        </div>
      </div>
      <div class="col-sm-6">
        <div class="form_group">
          <input class="form_control" type="text" name="mname" placeholder="Middle Name">
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-sm-6">
        <div class="form_group">
          <input class="form_control" type="text" name="lname" placeholder="Last Name">
        </div>
      </div>
      <div class="col-sm-6">
        <select name="user_role" class="form_control custom-select">
          <option value="" selected disabled hidden>Choose academic role</option>
          <option value="academicstaff">Academic Staff</option>
          <option value="casualstaff">Casual Staff</option>
          <option value="parttimestaff">Parttime Staff</option>
          <option value="staff">Staff</option>
          <option value="admin">Administrator</option>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="col-sm-8">
        <div class="form_group">
          <input class="form_control" type="email" name="email" placeholder="Email address">
        </div>
      </div>
      <div class="col-sm-4">
        <div class="form_group">
          <div class="form_option">
            <input class="form_control" type="text" name="hours" placeholder="Teaching allocation">
            <span class="optform_text">%</span>
          </div>
        </div>
      </div>
    </div>
    <div class="form_group pt-20">
      <label class="custom-check">
        <input type="checkbox">
        <span class="custom-input"></span>
        <span class="custom-label">Create profile and email login details to staff.</span>
      </label>
    </div>
    <div class="submit_wrapper">
      <input class="button" type="submit" value="Register">
    </div>
  </form>
</div>
