<?php 
function random_color_part() {
  return str_pad( dechex( mt_rand( 0, 255 ) ), 2, '0', STR_PAD_LEFT);
}

function random_color() {
  return random_color_part() . random_color_part() . random_color_part();
}
?>
<div class="general__holder">
  <header class="heading__wrapper">
    <a href="/unit-add" class="button">Add new unit</a>
    <h1>Manage Units</h1>
    <p>Manage units and activities associated with units.</p>
  </header>
  <table class="data__table">
    <thead>
      <tr>
        <th>&nbsp;</th>
        <th>Unit Name</th>
        <th>Unit Id</th>
        <th>Activities</th>
        <th>Activites last modified</th>
        <th>&nbsp;</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($units as $unit) : ?>
      <tr data-userid="<?= $unit->unit_id ?>">
        <td>
          <div class="user_profile" style="background-color: #<?= random_color(); ?>"><?= (int) filter_var($unit->unit_code, FILTER_SANITIZE_NUMBER_INT); ?></div>
        </td>
        <td>
          <div class="unit_name"><?= $unit->unit_name ?></div>
        </td>
        <td>
          <div class="unit_code"><?= $unit->unit_code ?></div>
        </td>
        <td>
          <div class="activity__wrapper">
            <?php if($unit->activities != NULL): ?>
              <ul class="unit_activities">
                  <?php
                    $act = $unit->activities;
                    $activity = explode(",", $act);
                    foreach($activity as $a): 
                  ?>
                    <li><?= $a ?> <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a></li>
                  <?php endforeach;?>
              </ul>
            <?php endif; ?>
          </div>
        </td>
        <td>
          <?php if($unit->activities_modified != NULL): ?>
            <?= $unit->activities_modified ?>
          <?php else: ?>
             Not Modfied
          <?php endif; ?>
        </td>
        <td>
          <a href="#" class="button button-small button-nobg">Edit unit</a>
          <a href="#" class="button button-small delete-obj" data-object="<?= $unit->unit_id ?>">Delete unit</a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
