
    </div>
  </div>
<footer class="footer">
  <em>&copy; 2019</em>
</footer>
<script src="<?= base_url(); ?>assets/js/main.js"></script>
</body>
</html>
