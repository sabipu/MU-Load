<?php
  defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>CodeIgniter Tutorial</title>
  <link rel="stylesheet" href="<?= base_url(); ?>assets/css/main.css">
</head>
<body>
  <h1>I am header</h1>
