<div class="general__holder">
  <div class="threecolumns">
    <div class="column">
      <h3 class="column__title">Previous Allocation</h3>
      <div class="info__box">
        <a href="/allocation/allocate?r=<?= date("Y"); ?>">
          <span class="info">Y1</span>
          <div class="text-wrap">
            <span class="status">Allocation Done</span>
            <h3>Year <span class="count"><?= date("Y"); ?></span></h3>
          </div>
        </a>
      </div>
    </div>
    <div class="column">
      <h3 class="column__title">Current Allocation</h3>
      <div class="info__box trimester">
        <a href="/allocation/allocate?r=<?= date("Y") + 1; ?>">
          <span class="info">Y1</span>
          <div class="text-wrap">
            <span class="status">Allocation Pending</span>
            <h3>Year <span class="count"><?= date("Y") + 1; ?></span></h3>
          </div>
        </a>
      </div>
    </div>
    <div class="column">
      <h3 class="column__title">Next Allocation</h3>
      <div class="info__box previous">
        <a href="/allocation/allocate?r=<?= date("Y") + 2; ?>">
          <span class="info">Y1</span>
          <div class="text-wrap">
            <span class="status">Allocation Pending</span>
            <h3>Year <span class="count"><?= date("Y") + 2; ?></span></h3>
          </div>
        </a>
      </div>
    </div>
  </div>
</div>
