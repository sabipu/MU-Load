<div class="general__holder">
  <!-- <header class="heading__wrapper">
    <div class="current_year">Year: <?= $_GET["r"] ?></div>
  </header> -->
  <div class="allocate__wrapper">
    <div class="column">
      <div class="unit__box">
        <div class="unit__title">ICT 621</div>
        <div class="teaching__period">
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">S1</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">S2</span>
              </label>
            </li>
          </div>
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TJA</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TMA</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TSA</span>
              </label>
            </li>
          </div>
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TJD</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TMD</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TSD</span>
              </label>
            </li>
          </div>
        </div>
        <div class="unit__activities">
          <ul class="acti__list">
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Lab</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Workshop</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Lecture</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
          </ul>
          <a href="#" class="add-btn">+ Add activity</a>
        </div>
      </div>
    </div>
    <div class="column">
      <div class="unit__box">
        <div class="unit__title">ICT 621</div>
        <div class="teaching__period">
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">S1</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">S2</span>
              </label>
            </li>
          </div>
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TJA</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TMA</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TSA</span>
              </label>
            </li>
          </div>
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TJD</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TMD</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TSD</span>
              </label>
            </li>
          </div>
        </div>
        <div class="unit__activities">
          <ul class="acti__list">
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Lab</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Workshop</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Lecture</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
          </ul>
          <a href="#" class="add-btn">+ Add activity</a>
        </div>
      </div>
    </div>
    <div class="column">
      <div class="unit__box">
        <div class="unit__title">ICT 621</div>
        <div class="teaching__period">
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">S1</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">S2</span>
              </label>
            </li>
          </div>
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TJA</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TMA</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TSA</span>
              </label>
            </li>
          </div>
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TJD</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TMD</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TSD</span>
              </label>
            </li>
          </div>
        </div>
        <div class="unit__activities">
          <ul class="acti__list">
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Lab</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Workshop</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Lecture</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
          </ul>
          <a href="#" class="add-btn">+ Add activity</a>
        </div>
      </div>
    </div>
    <div class="column">
      <div class="unit__box">
        <div class="unit__title">ICT 621</div>
        <div class="teaching__period">
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">S1</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">S2</span>
              </label>
            </li>
          </div>
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TJA</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TMA</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TSA</span>
              </label>
            </li>
          </div>
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TJD</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TMD</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TSD</span>
              </label>
            </li>
          </div>
        </div>
        <div class="unit__activities">
          <ul class="acti__list">
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Lab</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Workshop</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Lecture</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
          </ul>
          <a href="#" class="add-btn">+ Add activity</a>
        </div>
      </div>
    </div>
    <div class="column">
      <div class="unit__box">
        <div class="unit__title">ICT 621</div>
        <div class="teaching__period">
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">S1</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">S2</span>
              </label>
            </li>
          </div>
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TJA</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TMA</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TSA</span>
              </label>
            </li>
          </div>
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TJD</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TMD</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TSD</span>
              </label>
            </li>
          </div>
        </div>
        <div class="unit__activities">
          <ul class="acti__list">
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Lab</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Workshop</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Lecture</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
          </ul>
          <a href="#" class="add-btn">+ Add activity</a>
        </div>
      </div>
    </div>
    <div class="column">
      <div class="unit__box">
        <div class="unit__title">ICT 621</div>
        <div class="teaching__period">
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">S1</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">S2</span>
              </label>
            </li>
          </div>
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TJA</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TMA</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TSA</span>
              </label>
            </li>
          </div>
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TJD</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TMD</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TSD</span>
              </label>
            </li>
          </div>
        </div>
        <div class="unit__activities">
          <ul class="acti__list">
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Lab</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Workshop</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Lecture</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
          </ul>
          <a href="#" class="add-btn">+ Add activity</a>
        </div>
      </div>
    </div>
    <div class="column">
      <div class="unit__box">
        <div class="unit__title">ICT 621</div>
        <div class="teaching__period">
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">S1</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">S2</span>
              </label>
            </li>
          </div>
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TJA</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TMA</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TSA</span>
              </label>
            </li>
          </div>
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TJD</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TMD</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TSD</span>
              </label>
            </li>
          </div>
        </div>
        <div class="unit__activities">
          <ul class="acti__list">
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Lab</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Workshop</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Lecture</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
          </ul>
          <a href="#" class="add-btn">+ Add activity</a>
        </div>
      </div>
    </div>
    <div class="column">
      <div class="unit__box">
        <div class="unit__title">ICT 621</div>
        <div class="teaching__period">
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">S1</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">S2</span>
              </label>
            </li>
          </div>
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TJA</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TMA</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TSA</span>
              </label>
            </li>
          </div>
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TJD</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TMD</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TSD</span>
              </label>
            </li>
          </div>
        </div>
        <div class="unit__activities">
          <ul class="acti__list">
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Lab</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Workshop</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Lecture</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
          </ul>
          <a href="#" class="add-btn">+ Add activity</a>
        </div>
      </div>
    </div>
    <div class="column">
      <div class="unit__box">
        <div class="unit__title">ICT 621</div>
        <div class="teaching__period">
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">S1</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">S2</span>
              </label>
            </li>
          </div>
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TJA</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TMA</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TSA</span>
              </label>
            </li>
          </div>
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TJD</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TMD</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TSD</span>
              </label>
            </li>
          </div>
        </div>
        <div class="unit__activities">
          <ul class="acti__list">
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Lab</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Workshop</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Lecture</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
          </ul>
          <a href="#" class="add-btn">+ Add activity</a>
        </div>
      </div>
    </div>
    <div class="column">
      <div class="unit__box">
        <div class="unit__title">ICT 621</div>
        <div class="teaching__period">
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">S1</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">S2</span>
              </label>
            </li>
          </div>
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TJA</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TMA</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TSA</span>
              </label>
            </li>
          </div>
          <div class="teaching__list">
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TJD</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TMD</span>
              </label>
            </li>
            <li>
              <label class="custom-check">
                <input type="checkbox">
                <span class="custom-input"></span>
                <span class="custom-label">TSD</span>
              </label>
            </li>
          </div>
        </div>
        <div class="unit__activities">
          <ul class="acti__list">
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Lab</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Workshop</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
            <li>
              <a href="#" class="close"><?= file_get_contents(base_url() . 'assets/svg/close.svg') ?></a>
              <div class="row">
                <div class="col-xs-3">
                  <span class="activity__title">Lecture</span>
                </div>
                <div class="col-xs-9">
                  <div class="lecturer__wrapper">
                    <span class="hr_count">1075</span>
                    <input type="text" class="input__control" placeholder="Assign Lecturer">
                  </div>
                </div>
              </div>
            </li>
          </ul>
          <a href="#" class="add-btn">+ Add activity</a>
        </div>
      </div>
    </div>
    <div class="column">
      <div class="add__button">
          <div class="add__buttonwrap">
            <a href="#"><span>+ <span class="txt">Add unit</span></span></a>
          </div>
      </div>
    </div>
  </div>
  <div class="control__wrapper">
    <label class="custom-check">
      <input type="checkbox" id="apply-changes">
      <span class="custom-input"></span>
      <span class="custom-label">Apply all changes.</span>
    </label>
    <a href="#" class="button">Apply allocation</a>
  </div>
</div>
