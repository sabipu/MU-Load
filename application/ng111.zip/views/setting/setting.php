<div class="general__holder">
  <header class="heading__wrapper">
    <h1>Manage Global Settings</h1>
  </header>
  <table class="data__table">
    <thead>
      <tr>
        <th>Title</th>
        <th>Value</th>
        <th>Comment</th>
        <th>&nbsp;</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>
          <span class="global__data">Total Teacing Hour per staff</span>
        </td>
        <td>
          <span class="global__data">1750 hrs</span>
        </td>
        <td class="text-left">
          
        </td>
        <td>
          <a href="#" class="button button-small">Edit</a>
        </td>
      </tr>

      <tr>
        <td>
          <span class="global__data">Total Casual Budget</span>
        </td>
        <td>
          <span class="global__data">$100,000</span>
        </td>
        <td class="text-left">
          Year: 2019
        </td>
        <td>
          <a href="#" class="button button-small">Edit</a>
        </td>
      </tr>
      <tr>
        <td>
          <span class="global__data">Casual Staff Hourly Rate</span>
        </td>
        <td>
          <span class="global__data">$45</span>
        </td>
        <td class="text-left">
          
        </td>
        <td>
          <a href="#" class="button button-small">Edit</a>
        </td>
      </tr>
    </tbody>
  </table>
  <!-- <form method="post" class="register__form general__form" action="<?php echo site_url('unit/add') ?>">
    <div class="row">
      <div class="col-sm-6">
        <div class="form_group">
          <input class="form_control" type="text" name="unit_name" placeholder="Unit name">
        </div>
      </div>
      <div class="col-sm-6">
        <div class="form_group">
          <input class="form_control" type="text" name="unit_code" placeholder="Unit Code">
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-sm-6">
        <div class="form_group">
          <input class="form_control" type="text" name="unit_activities" placeholder="Activities">
        </div>
      </div>
      <div class="col-sm-6">
        <div class="form_group">
          <select name="user_role" class="form_control custom-select">
            <option value="" selected disabled hidden>Choose academic session</option>
            <option value="semester">Semester</option>
            <option value="trimester">Trimester</option>
            <option value="both">Both</option>
          </select>
        </div>
      </div>
    </div>
    <div class="submit_wrapper">
      <input class="button" type="submit" value="Register">
    </div>
  </form> -->
</div>